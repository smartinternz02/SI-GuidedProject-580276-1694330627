package com.example.diceroller

import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import android.widget.ImageView
import android.widget.TextView

import java.util.*

class MainActivity : ComponentActivity() {
    private lateinit var dice: ImageView
    private lateinit var resultTextView: TextView
    private lateinit var button: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        resultTextView = findViewById(R.id.resultTextView)
        dice = findViewById(R.id.dice)
        button = findViewById(R.id.button)

        button.setOnClickListener {
            rolldice()
        }
        }
    private fun rolldice() {
        val random = java.util.Random()
        val randomNumber = random.nextInt(6) + 1
        val resultText = "You rolled a $randomNumber"
        resultTextView.text = resultText

        val drawableResource = when (randomNumber) {
            1 -> R.drawable.dice1
            2 -> R.drawable.dice2
            3 -> R.drawable.dice3
            4 -> R.drawable.dice4
            5 -> R.drawable.dice5
            else -> R.drawable.dice6
        }
        dice.setImageResource(drawableResource)
    }
}
