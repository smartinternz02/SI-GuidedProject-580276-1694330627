package com.arvind.foodizone.model

data class Menu(
    val categories: List<Categories>,
    val menuItems: List<MenuItem>
)
