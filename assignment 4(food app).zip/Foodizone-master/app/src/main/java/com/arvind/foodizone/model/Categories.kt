package com.arvind.foodizone.model

data class Categories(
    val id: Long,
    val name: String,
    val image: String
)
