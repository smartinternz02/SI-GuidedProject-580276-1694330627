# Foodizone
New style for app design Foodizone 🍔 App UI made in Jetpack Compose.😉😎

(Latest Android Studio Bumblebee, Navigation Components,
Dagger-Hilt,Material Components)

# Screenshot

![Foodizone 🍔 on Behance](https://user-images.githubusercontent.com/25154589/155497551-d350a5c6-1fb4-41c1-a4a0-74c11532f523.png)


►Design Credit: https://www.behance.net/gallery/129879175/Foodizone-
